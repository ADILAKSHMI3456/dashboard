import React, { useContext } from 'react';
import { ToastContext } from '../../context/ToastContext';

function Toast() {
  const { toasts } = useContext(ToastContext);

  if (!toasts || !Array.isArray(toasts)) {
    return null; // Prevent rendering if toasts is undefined or not an array
  }

  return (
    <div className="fixed top-4 right-4 space-y-2 z-50">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`p-4 rounded-lg shadow-lg text-white ${
            toast.type === 'success' ? 'bg-green-500' : 'bg-red-500'
          } animate-slide-in`}
        >
          {toast.message}
        </div>
      ))}
    </div>
  );
}

export default Toast;