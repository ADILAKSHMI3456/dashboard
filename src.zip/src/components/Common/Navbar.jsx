import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { ToastContext } from '../../context/ToastContext';

function Navbar({ user }) {
  const navigate = useNavigate();
  const { logout } = useContext(AuthContext);
  const { showToast } = useContext(ToastContext);
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const handleLogoutClick = () => {
    setShowLogoutModal(true);
  };

  const confirmLogout = () => {
    logout();
    showToast('Logged out successfully', 'success');
    navigate('/login');
    setShowLogoutModal(false);
  };

  const cancelLogout = () => {
    setShowLogoutModal(false);
  };

  return (
    <>
      <nav className="bg-blue-600 text-white p-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1
            onClick={() => navigate('/')}
            className="text-2xl font-bold cursor-pointer"
          >
            Dental Center
          </h1>

          <div className="flex items-center space-x-4">
            {user && (
              <>
                <span className="text-sm hidden sm:block">
                  {user.email} ({user.role})
                </span>

                {user.role === 'Admin' && (
                  <>
                    <button
                      onClick={() => navigate('/dashboard')}
                      className="hover:underline hover:text-blue-200"
                    >
                      Dashboard
                    </button>
                    <button
                      onClick={() => navigate('/patients')}
                      className="hover:underline hover:text-blue-200"
                    >
                      Patients
                    </button>
                    <button
                      onClick={() => navigate('/incidents')}
                      className="hover:underline hover:text-blue-200"
                    >
                      Incidents
                    </button>
                    <button
                      onClick={() => navigate('/calendar')}
                      className="hover:underline hover:text-blue-200"
                    >
                      Calendar
                    </button>
                  </>
                )}

                {user.role === 'Patient' && (
                  <>
                    <button
                      onClick={() => navigate('/my-profile')}
                      className="hover:underline hover:text-blue-200"
                    >
                      Profile
                    </button>
                    <button
                      onClick={() => navigate('/my-incidents')}
                      className="hover:underline hover:text-blue-200"
                    >
                      Incidents
                    </button>
                  </>
                )}

                <button
                  onClick={handleLogoutClick}
                  className="bg-red-500 text-white px-3 py-1 rounded-lg hover:bg-red-600 transition hover:scale-105"
                >
                  Logout
                </button>
              </>
            )}
          </div>
        </div>
      </nav>

      {showLogoutModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white text-black p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h2 className="text-xl font-semibold mb-4">Confirm Logout</h2>
            <p className="mb-4">Are you sure you want to log out?</p>
            <div className="flex justify-end gap-4">
              <button
                onClick={confirmLogout}
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition"
              >
                Yes, Log Out
              </button>
              <button
                onClick={cancelLogout}
                className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default Navbar;
