import React from 'react';
import { useNavigate } from 'react-router-dom';

const Banner = () => {
  const navigate = useNavigate();

  return (
    <div className="relative w-full">
      {/* Banner Image with Text Overlay */}
      <div className="relative w-full h-[60vh] sm:h-[70vh] md:h-[80vh] lg:h-[90vh]">
        <img
          src="https://images.pexels.com/photos/3845653/pexels-photo-3845653.jpeg"
          alt="Dental Clinic"
          className="w-full h-full object-cover"
        />

       
        {/* Centered Welcome Message */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white drop-shadow-md">
            Welcome to Dental Center
          </h1>
          <p className="mt-4 text-base sm:text-lg text-white max-w-xl drop-shadow">
            Your smile is our priority. Book an appointment today!
          </p>
          <button
            onClick={() => navigate('/services')}
            className="mt-6 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg text-sm sm:text-base transition-transform hover:scale-105"
          >
            Explore Services
          </button>
        </div>
      </div>
    </div>
  );
};

export default Banner;
