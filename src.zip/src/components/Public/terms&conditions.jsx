import React from 'react';

function TermsAndConditionsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* 🔵 Banner Section */}
      <div className="bg-blue-800 text-white py-16 px-6 text-center shadow-md">
        <h1 className="text-4xl font-bold mb-2">Terms & Conditions</h1>
        <p className="text-lg text-blue-100">
          Please read our terms and conditions before using our services.
        </p>
      </div>

      {/* 📄 Terms Content */}
      <div className="max-w-4xl mx-auto py-12 px-6">
        <p className="text-gray-700 mb-4">
          By accessing and using the Dental Center website or services, you agree to comply with and be bound by the following terms and conditions.
        </p>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">1. Use of Website</h2>
        <p className="text-gray-700">
          The content on this site is for general informational purposes only. It is not a substitute for professional dental advice or treatment.
        </p>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">2. Appointments and Cancellations</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>Appointments can be scheduled online or by phone.</li>
          <li>We require at least 24 hours’ notice for cancellations or rescheduling.</li>
          <li>Late cancellations may be subject to a fee.</li>
        </ul>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">3. Payments</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>All services must be paid for at the time of treatment unless otherwise agreed.</li>
          <li>We accept various payment methods including insurance, credit/debit cards, and cash.</li>
        </ul>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">4. Intellectual Property</h2>
        <p className="text-gray-700">
          All content, logos, and images on this site are the property of Dental Center and may not be reproduced or reused without permission.
        </p>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">5. Privacy</h2>
        <p className="text-gray-700">
          Your privacy is important to us. Please refer to our{' '}
          <a href="/privacy-policy" className="text-blue-600 hover:underline">Privacy Policy</a> for details on how we handle your data.
        </p>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">6. Modifications</h2>
        <p className="text-gray-700">
          We reserve the right to update or modify these terms at any time. Continued use of the site or services constitutes acceptance of those changes.
        </p>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">7. Contact</h2>
        <p className="text-gray-700">
          If you have any questions about these terms, please contact us:
        </p>
        <p className="text-gray-700 mt-2">📧 info@dentalcenter.com</p>
        <p className="text-gray-700">📞 (123) 456-7890</p>

        <p className="text-gray-500 text-sm mt-12">
          Last updated: {new Date().toLocaleDateString()}
        </p>
      </div>
    </div>
  );
}

export default TermsAndConditionsPage;
