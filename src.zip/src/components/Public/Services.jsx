import React from 'react';

const services = [
  {
    id: 1,
    title: 'Teeth Cleaning',
    description: 'Professional cleaning to remove plaque and tartar, keeping your teeth healthy and bright.',
    icon: (
      // Toothbrush icon
      <svg
        className="w-10 h-10 text-blue-600"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M4 16l1.5 1.5m4-4l9-9a1.5 1.5 0 012.12 2.12l-9 9M7 13l-3 3m1-7l2-2m3-2l5 5"
        />
      </svg>
    ),
  },
  {
    id: 2,
    title: 'Cavity Filling',
    description: 'Safe and effective fillings to restore teeth affected by decay and prevent further damage.',
    icon: (
      // Tooth with a cavity/crack icon
      <svg
        className="w-10 h-10 text-green-600"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M12 3c-3.5 0-6 2.5-6 6 0 2.5 1.5 4 3 5.5 1.5 1.5 3 2.5 3 2.5s1.5-1 3-2.5c1.5-1.5 3-3 3-5.5 0-3.5-2.5-6-6-6z"
        />
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M9 9l6 6"
        />
      </svg>
    ),
  },
  {
    id: 3,
    title: 'Orthodontics',
    description: 'Braces and aligners to straighten teeth and improve bite for a confident smile.',
    icon: (
      // Braces icon (stylized)
      <svg
        className="w-10 h-10 text-purple-600"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect
          x="4"
          y="7"
          width="16"
          height="10"
          rx="2"
          ry="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M8 7v10M16 7v10M6 12h12"
        />
      </svg>
    ),
  },
  {
    id: 4,
    title: 'Teeth Whitening',
    description: 'Brighten your smile with safe whitening treatments tailored to your needs.',
    icon: (
      // Sparkles / shine icon
      <svg
        className="w-10 h-10 text-yellow-500"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M12 3v18m9-9H3m7-7l3 3m-3 8l3-3"
        />
      </svg>
    ),
  },
  {
    id: 5,
    title: 'Dental Implants',
    description: 'Permanent replacements for missing teeth that look and function like natural teeth.',
    icon: (
      // Implant screw icon (stylized tooth with screw)
      <svg
        className="w-10 h-10 text-red-600"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M9 17l6-10M12 20v-6M9 12h6"
        />
      </svg>
    ),
  },
];

function ServicesPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-blue-800 mb-8 text-center">Our Dental Services</h1>

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ id, title, description, icon }) => (
            <div
              key={id}
              className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center text-center hover:shadow-xl transition"
            >
              <div className="mb-4">{icon}</div>
              <h2 className="text-2xl font-semibold mb-2">{title}</h2>
              <p className="text-gray-600">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ServicesPage;
