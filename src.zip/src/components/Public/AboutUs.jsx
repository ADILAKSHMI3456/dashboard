import React from 'react';

function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-12">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
        
        {/* Image side */}
        <div className="flex justify-center">
          <img
            src="https://images.pexels.com/photos/3845723/pexels-photo-3845723.jpeg"
            alt="Dental care"
            className="rounded-lg shadow-lg object-cover max-h-96"
          />
        </div>

        {/* Text side */}
        <div className="text-gray-800 space-y-6 px-4">
          <h2 className="text-4xl font-bold text-blue-800">About Dental Care</h2>
          <p className="text-lg leading-relaxed">
            At Dental Center, we are dedicated to providing comprehensive and compassionate dental care
            to help you maintain a healthy, confident smile. Our experienced team uses state-of-the-art
            technology and techniques to ensure the best outcomes for every patient.
          </p>
          <p className="text-lg leading-relaxed">
            From routine checkups and cleanings to advanced restorative treatments, we focus on
            personalized care tailored to your unique needs. Your oral health and comfort are our top priorities,
            and we strive to make every visit a positive experience.
          </p>
          <p className="text-lg leading-relaxed">
            Regular dental care not only keeps your teeth and gums healthy but also helps prevent
            other health issues. Trust Dental Center to guide you on your path to optimal dental wellness.
          </p>
        </div>

      </div>
    </div>
  );
}

export default AboutPage;
