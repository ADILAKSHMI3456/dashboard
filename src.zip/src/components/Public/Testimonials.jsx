import React, { useState, useEffect } from 'react';

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    photo: 'https://randomuser.me/api/portraits/women/44.jpg',
    feedback:
      'The Dental Center team was amazing! They made me feel comfortable during my teeth cleaning and the results were fantastic. Highly recommend!',
  },
  {
    id: 2,
    name: 'Mark Stevens',
    photo: 'https://randomuser.me/api/portraits/men/35.jpg',
    feedback:
      'I got my cavity filled here and the procedure was painless and quick. The staff was very professional and caring.',
  },
  {
    id: 3,
    name: 'Emily Davis',
    photo: 'https://randomuser.me/api/portraits/women/68.jpg',
    feedback:
      'Thanks to the orthodontics service, my smile has completely transformed. The braces felt comfortable and the team guided me every step of the way.',
  },
  {
    id: 4,
    name: 'James Wilson',
    photo: 'https://randomuser.me/api/portraits/men/22.jpg',
    feedback:
      'I had dental implants done here and couldn’t be happier. The process was smooth and now I have a natural-looking smile again!',
  },
];

function TestimonialsPage() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    }, 3000);

    return () => clearInterval(timer);
  }, []);

  const { name, photo, feedback } = testimonials[currentIndex];

  return (
    <div className="min-h-screen bg-gray-50 py-16 px-4 flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold text-blue-800 mb-12 text-center">What Our Patients Say</h1>

      <div className="w-full max-w-3xl bg-white p-10 rounded-lg shadow-md flex flex-col items-center text-center transition-all duration-500">
        <img
          src={photo}
          alt={`${name} photo`}
          className="w-32 h-32 rounded-full object-cover mb-6 border-4 border-blue-600"
        />
        <h3 className="text-2xl font-semibold text-blue-800 mb-4">{name}</h3>
        <p className="text-gray-700 italic text-lg max-w-xl">"{feedback}"</p>
      </div>

      {/* Pagination dots */}
      <div className="flex space-x-4 mt-8">
        {testimonials.map((_, idx) => (
          <button
            key={idx}
            className={`text-3xl leading-none transition-colors ${
              idx === currentIndex ? 'text-blue-600' : 'text-gray-400'
            }`}
            aria-label={`Go to testimonial ${idx + 1}`}
            onClick={() => setCurrentIndex(idx)}
          >
            &bull;
          </button>
        ))}
      </div>
    </div>
  );
}

export default TestimonialsPage;
