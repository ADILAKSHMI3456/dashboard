import React from 'react';
import { useNavigate } from 'react-router-dom';
import Homenavbar from './homenavbar';
import Banner from './banner';
import AboutPage from './AboutUs';
import ServicesPage from './Services';
import TestimonialsPage from './Testimonials';
import HomeFooter from './homefooter';

function Home() {
  const navigate = useNavigate();

  return (
    <>
    <Homenavbar />
    <Banner />
    <AboutPage />
    <ServicesPage />
    <TestimonialsPage/>
    <HomeFooter />
    </>
  );

}

export default Home;