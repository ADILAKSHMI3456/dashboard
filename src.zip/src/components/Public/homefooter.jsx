import React from 'react';

function HomeFooter() {
  return (
    <footer className="bg-blue-900 text-white py-10 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
        {/* About */}
        <div>
          <h2 className="text-xl font-semibold mb-4">About Us</h2>
          <p className="text-sm text-gray-300">
            Dental Center is committed to providing quality dental care with modern techniques and a gentle touch.
          </p>
        </div>

        {/* FAQ */}
        <div>
          <h2 className="text-xl font-semibold mb-4">FAQ</h2>
          <ul className="text-sm space-y-2 text-gray-300">
            <li>How do I book an appointment?</li>
            <li>Do you accept insurance?</li>
            <li>What should I bring to my first visit?</li>
            <li>How often should I get a cleaning?</li>
          </ul>
        </div>

        {/* Policies */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Legal</h2>
          <ul className="text-sm space-y-2 text-gray-300">
            <li>
              <a href="/privacy-policy" className="hover:underline">Privacy Policy</a>
            </li>
            <li>
              <a href="/terms" className="hover:underline">Terms & Conditions</a>
            </li>
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
          <ul className="text-sm text-gray-300 space-y-2">
            <li>📍 123 Smile St, Tooth City, TX</li>
            <li>📞 (123) 456-7890</li>
            <li>✉️ info@dentalcenter.com</li>
          </ul>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="text-center text-sm text-gray-400 mt-10 border-t border-blue-800 pt-4">
        © {new Date().getFullYear()} Dental Center. All rights reserved.
      </div>
    </footer>
  );
}

export default HomeFooter;
