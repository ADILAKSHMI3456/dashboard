import React from 'react';

function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* 🔵 Banner Section */}
      <div className="bg-blue-800 text-white py-16 px-6 text-center shadow-md">
        <h1 className="text-4xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-lg text-blue-100">
          Your trust is important to us. Here's how we protect your personal information.
        </p>
      </div>

      {/* 📄 Policy Content */}
      <div className="max-w-4xl mx-auto py-12 px-6">
        <p className="text-gray-700 mb-4">
          At Dental Center, we respect your privacy and are committed to protecting your personal data. This Privacy Policy
          explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
        </p>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">1. Information We Collect</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>Personal information (name, phone number, email address, etc.)</li>
          <li>Health and dental history (when submitted via forms)</li>
          <li>Appointment and billing details</li>
          <li>Browser data, IP address, and cookies</li>
        </ul>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">2. How We Use Your Information</h2>
        <p className="text-gray-700 mb-4">We use the information we collect to:</p>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>Schedule and manage appointments</li>
          <li>Communicate with you about your care or inquiries</li>
          <li>Improve our website and services</li>
          <li>Send you reminders or updates (only with consent)</li>
        </ul>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">3. Sharing Your Information</h2>
        <p className="text-gray-700">We do not sell or rent your personal information. We may share your data only with:</p>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>Authorized staff and dental professionals for treatment purposes</li>
          <li>Payment processors for billing</li>
          <li>Legal authorities if required by law</li>
        </ul>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">4. Your Rights</h2>
        <p className="text-gray-700 mb-4">You have the right to:</p>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>Access the personal information we have about you</li>
          <li>Request corrections or deletion of your data</li>
          <li>Withdraw consent at any time</li>
        </ul>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">5. Security</h2>
        <p className="text-gray-700 mb-4">
          We implement industry-standard security measures to protect your data. However, no method of transmission over
          the internet is 100% secure.
        </p>

        <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-2">6. Contact Us</h2>
        <p className="text-gray-700">If you have any questions or concerns about this Privacy Policy, please contact us at:</p>
        <p className="text-gray-700 mt-2">📧 info@dentalcenter.com</p>
        <p className="text-gray-700">📞 (123) 456-7890</p>

        <p className="text-gray-500 text-sm mt-12">
          Last updated: {new Date().toLocaleDateString()}
        </p>
      </div>
    </div>
  );
}

export default PrivacyPolicyPage;
