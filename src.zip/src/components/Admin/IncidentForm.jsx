import React, { useState, useEffect, useContext } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getIncidents, setIncidents, getPatients } from '../../utils/localStorage';
import { ToastContext } from '../../context/ToastContext';
import Navbar from '../Common/Navbar';
import { AuthContext } from '../../context/AuthContext';

function IncidentForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast } = useContext(ToastContext);
  const { user } = useContext(AuthContext);
  const patients = getPatients();
  const [incident, setIncident] = useState({
    patientId: '',
    title: '',
    description: '',
    comments: '',
    appointmentDate: '',
    cost: '',
    treatment: '',
    status: 'Pending',
    nextDate: '',
    files: [],
  });
  const [error, setError] = useState('');
  const [filePreviews, setFilePreviews] = useState([]);

  useEffect(() => {
    if (id) {
      const incidents = getIncidents();
      const existingIncident = incidents.find((i) => i.id === id);
      if (existingIncident) {
        setIncident(existingIncident);
        setFilePreviews(existingIncident.files);
      }
    }
  }, [id]);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    const newFiles = files.map((file) => {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve({ name: file.name, url: reader.result });
        reader.readAsDataURL(file);
      });
    });
    Promise.all(newFiles).then((newFileObjects) => {
      setIncident({ ...incident, files: [...incident.files, ...newFileObjects] });
      setFilePreviews([...filePreviews, ...newFileObjects]);
      showToast('Files uploaded successfully', 'success');
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!incident.patientId || !incident.title || !incident.appointmentDate) {
      setError('Please fill in all required fields');
      showToast('Please fill in all required fields', 'error');
      return;
    }
    const incidents = getIncidents();
    if (id) {
      const updatedIncidents = incidents.map((i) => (i.id === id ? incident : i));
      setIncidents(updatedIncidents);
      showToast('Incident updated successfully', 'success');
    } else {
      const newIncident = { ...incident, id: `i${incidents.length + 1}` };
      setIncidents([...incidents, newIncident]);
      showToast('Incident added successfully', 'success');
    }
    navigate('/incidents');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="hidden sm:block">
        <Navbar user={user} />
      </div>
      <div className="max-w-full sm:max-w-md mx-auto p-4 sm:p-6 lg:p-8">
        <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-blue-600">{id ? 'Edit Incident' : 'Add Incident'}</h2>
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg">
          {error && <p className="text-red-500 mb-4 text-sm sm:text-base">{error}</p>}
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Patient</label>
              <select
                value={incident.patientId}
                onChange={(e) => setIncident({ ...incident, patientId: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                required
              >
                <option value="">Select Patient</option>
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Title</label>
              <input
                type="text"
                value={incident.title}
                onChange={(e) => setIncident({ ...incident, title: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Description</label>
              <textarea
                value={incident.description}
                onChange={(e) => setIncident({ ...incident, description: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Comments</label>
              <textarea
                value={incident.comments}
                onChange={(e) => setIncident({ ...incident, comments: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Appointment Date</label>
              <input
                type="datetime-local"
                value={incident.appointmentDate}
                onChange={(e) => setIncident({ ...incident, appointmentDate: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Cost</label>
              <input
                type="number"
                value={incident.cost}
                onChange={(e) => setIncident({ ...incident, cost: parseFloat(e.target.value) })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Treatment</label>
              <input
                type="text"
                value={incident.treatment}
                onChange={(e) => setIncident({ ...incident, treatment: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Status</label>
              <select
                value={incident.status}
                onChange={(e) => setIncident({ ...incident, status: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              >
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Next Appointment Date</label>
              <input
                type="date"
                value={incident.nextDate}
                onChange={(e) => setIncident({ ...incident, nextDate: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Upload Files</label>
              <input
                type="file"
                multiple
                onChange={handleFileChange}
                className="w-full p-2 sm:p-3 border rounded-lg text-sm sm:text-base"
              />
              <div className="mt-2 space-y-2">
                {filePreviews.map((file, index) => (
                  <div key={index} className="flex items-center">
                    <a
                      href={file.url}
                      download={file.name}
                      className="text-blue-500 hover:underline hover:text-blue-600 text-sm sm:text-base"
                    >
                      {file.name}
                    </a>
                  </div>
                ))}
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-blue-500 text-white p-2 sm:p-3 rounded-lg hover:bg-blue-600 hover:scale-105 text-sm sm:text-base"
            >
              {id ? 'Update Incident' : 'Add Incident'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default IncidentForm;