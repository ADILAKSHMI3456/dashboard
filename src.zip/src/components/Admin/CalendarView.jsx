import React, { useState, useContext } from 'react';
import { getIncidents, getPatients } from '../../utils/localStorage';
import Navbar from '../Common/Navbar';
import Sidebar from './Sidebar';
import { AuthContext } from '../../context/AuthContext';

function CalendarView() {
  const { user } = useContext(AuthContext);
  const [currentDate, setCurrentDate] = useState(new Date());
  const incidents = getIncidents();
  const patients = getPatients();

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const getIncidentsForDay = (day) => {
    return incidents.filter((i) => {
      const date = new Date(i.appointmentDate);
      return (
        date.getDate() === day &&
        date.getMonth() === currentDate.getMonth() &&
        date.getFullYear() === currentDate.getFullYear()
      );
    });
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar user={user} />
      <div className="flex-1 ml-0 sm:ml-64 p-4 sm:p-6">
        <div className="hidden sm:block">
          <Navbar user={user} />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-6 text-blue-600">Calendar View</h1>
        <div className="flex justify-between mb-4">
          <button
            onClick={handlePrevMonth}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 hover:scale-105 text-sm sm:text-base"
          >
            Previous
          </button>
          <h2 className="text-lg sm:text-xl font-semibold text-gray-700">
            {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
          </h2>
          <button
            onClick={handleNextMonth}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 hover:scale-105 text-sm sm:text-base"
          >
            Next
          </button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div key={day} className="text-center font-semibold text-gray-700 hidden sm:block">
              {day}
            </div>
          ))}
          {Array(firstDay)
            .fill(null)
            .map((_, i) => (
              <div key={`empty-${i}`} className="bg-gray-200 p-2 sm:p-4 rounded-lg"></div>
            ))}
          {days.map((day) => (
            <div
              key={day}
              className="bg-white p-2 sm:p-4 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="font-bold text-blue-500 text-sm sm:text-base">{day}</div>
              {getIncidentsForDay(day).map((incident) => (
                <div key={incident.id} className="text-xs sm:text-sm mt-2 bg-gray-50 p-2 rounded">
                  {incident.title} - {patients.find((p) => p.id === incident.patientId)?.name || 'Unknown'}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default CalendarView;