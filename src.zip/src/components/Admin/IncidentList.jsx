import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { getIncidents, getPatients, setIncidents } from '../../utils/localStorage';
import { ToastContext } from '../../context/ToastContext';
import Navbar from '../Common/Navbar';
import Sidebar from './Sidebar';
import { AuthContext } from '../../context/AuthContext';

function IncidentList() {
  const navigate = useNavigate();
  const { showToast } = useContext(ToastContext);
  const { user } = useContext(AuthContext);
  const [incidents, setIncidents] = useState([]);
  const patients = getPatients();

  useEffect(() => {
    setIncidents(getIncidents());
  }, []);

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this incident?')) {
      const updatedIncidents = incidents.filter((i) => i.id !== id);
      setIncidents(updatedIncidents);
      setIncidents(updatedIncidents);
      showToast('Incident deleted successfully', 'success');
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar user={user} />
      <div className="flex-1 ml-0 sm:ml-64 p-15 sm:p-6">
        <div className="hidden sm:block">
          <Navbar user={user} />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-6 text-blue-600">Incident List</h1>
        <button
          onClick={() => navigate('/incidents/add')}
          className="bg-green-500 text-white px-4 py-2 rounded-lg mb-4 hover:bg-green-600 hover:scale-105 text-sm sm:text-base"
        >
          Add Incident
        </button>
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg overflow-x-auto">
          <table className="w-full min-w-max">
            <thead>
              <tr className="bg-blue-100 text-left">
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Patient</th>
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Title</th>
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Date</th>
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Status</th>
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Cost</th>
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Treatment</th>
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Next Date</th>
                <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Actions</th>
              </tr>
            </thead>
            <tbody>
              {incidents.map((incident) => (
                <tr key={incident.id} className="border-t hover:bg-gray-50 transition-colors">
                  <td className="p-2 sm:p-3 text-xs sm:text-sm">
                    {patients.find((p) => p.id === incident.patientId)?.name || 'Unknown'}
                  </td>
                  <td className="p-2 sm:p-3 text-xs sm:text-sm">{incident.title}</td>
                  <td className="p-2 sm:p-3 text-xs sm:text-sm">
                    {new Date(incident.appointmentDate).toLocaleString()}
                  </td>
                  <td className="p-2 sm:p-3 text-xs sm:text-sm">{incident.status}</td>
                  <td className="p-2 sm:p-3 text-xs sm:text-sm">${incident.cost || 0}</td>
                  <td className="p-2 sm:p-3 text-xs sm:text-sm">{incident.treatment || '-'}</td>
                  <td className="p-2 sm:p-3 text-xs sm:text-sm">{incident.nextDate || '-'}</td>
                  <td className="p-2 sm:p-3">
                    <button
                      onClick={() => navigate(`/incidents/edit/${incident.id}`)}
                      className="bg-blue-500 text-white px-2 sm:px-3 py-1 rounded-lg mr-2 hover:bg-blue-600 hover:scale-105 text-xs sm:text-sm"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(incident.id)}
                      className="bg-red-500 text-white px-2 sm:px-3 py-1 rounded-lg hover:bg-red-600 hover:scale-105 text-xs sm:text-sm"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default IncidentList;