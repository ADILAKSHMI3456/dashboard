import React, { useState, useEffect, useContext } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getPatients, setPatients } from '../../utils/localStorage';
import { ToastContext } from '../../context/ToastContext';
import Navbar from '../Common/Navbar';
import { AuthContext } from '../../context/AuthContext';

function PatientForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast } = useContext(ToastContext);
  const { user } = useContext(AuthContext);
  const [patient, setPatient] = useState({
    id: '',
    name: '',
    dob: '',
    contact: '',
    healthInfo: '',
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (id) {
      const patients = getPatients();
      const existingPatient = patients.find((p) => p.id === id);
      if (existingPatient) {
        setPatient(existingPatient);
      }
    }
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!patient.name || !patient.dob || !patient.contact) {
      setError('Please fill in all required fields');
      showToast('Please fill in all required fields', 'error');
      return;
    }
    const patients = getPatients();
    if (id) {
      const updatedPatients = patients.map((p) => (p.id === id ? patient : p));
      setPatients(updatedPatients);
      showToast('Patient updated successfully', 'success');
    } else {
      const newPatient = { ...patient, id: `p${patients.length + 1}` };
      setPatients([...patients, newPatient]);
      showToast('Patient added successfully', 'success');
    }
    navigate('/patients');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="hidden sm:block">
        <Navbar user={user} />
      </div>
      <div className="max-w-full sm:max-w-md mx-auto p-4 sm:p-6 lg:p-8">
        <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-blue-600">{id ? 'Edit Patient' : 'Add Patient'}</h2>
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg">
          {error && <p className="text-red-500 mb-4 text-sm sm:text-base">{error}</p>}
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Name</label>
              <input
                type="text"
                value={patient.name}
                onChange={(e) => setPatient({ ...patient, name: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Date of Birth</label>
              <input
                type="date"
                value={patient.dob}
                onChange={(e) => setPatient({ ...patient, dob: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Contact</label>
              <input
                type="text"
                value={patient.contact}
                onChange={(e) => setPatient({ ...patient, contact: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-1 text-sm sm:text-base">Health Info</label>
              <textarea
                value={patient.healthInfo}
                onChange={(e) => setPatient({ ...patient, healthInfo: e.target.value })}
                className="w-full p-2 sm:p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm sm:text-base"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-500 text-white p-2 sm:p-3 rounded-lg hover:bg-blue-600 hover:scale-105 text-sm sm:text-base"
            >
              {id ? 'Update Patient' : 'Add Patient'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default PatientForm;