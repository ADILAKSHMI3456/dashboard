import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';

function Sidebar({ user }) {
  const navigate = useNavigate();
  const { logout } = useContext(AuthContext); // 👈 Get logout from context
  const [isCollapsed, setIsCollapsed] = useState(true);

  const toggleSidebar = () => setIsCollapsed(!isCollapsed);

  const handleNavigation = (path) => {
    navigate(path);
    setIsCollapsed(true); // Close sidebar on mobile
  };

  const handleLogout = () => {
    logout();            // Clear auth context / token
    navigate('/');       // Redirect to home or login
  };

  return (
    <>
      {/* Overlay */}
      {!isCollapsed && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 sm:hidden"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <div
        className={`
          fixed inset-y-0 left-0 bg-gray-800 text-white shadow-lg z-50 transition-transform duration-300
          w-64 transform
          ${isCollapsed ? '-translate-x-full sm:translate-x-0' : 'translate-x-0'}
        `}
      >
        {/* Close button (mobile) */}
        <div className="sm:hidden flex justify-end p-4">
          <button
            onClick={toggleSidebar}
            className="text-gray-300 hover:text-white text-2xl"
          >
            ✖
          </button>
        </div>

        {/* Logo & Info */}
        <div className="px-4 pb-6 hidden sm:block">
          <h2 className="text-xl font-bold">Dental Center</h2>
          <p className="text-sm text-gray-400">
            {user?.email} ({user?.role})
          </p>
        </div>

        {/* Navigation */}
        <nav className="px-4 space-y-10">
          {user?.role === 'Admin' && (
            <>
              <button onClick={() => handleNavigation('/dashboard')} className="w-full text-left p-2 hover:bg-gray-700 rounded">
                Dashboard
              </button>
              <button onClick={() => handleNavigation('/patients')} className="w-full text-left p-2 hover:bg-gray-700 rounded">
                Patients
              </button>
              <button onClick={() => handleNavigation('/incidents')} className="w-full text-left p-2 hover:bg-gray-700 rounded">
                Incidents
              </button>
              <button onClick={() => handleNavigation('/calendar')} className="w-full text-left p-2 hover:bg-gray-700 rounded">
                Calendar
              </button>
            </>
          )}

          {user?.role === 'Patient' && (
            <>
              <button onClick={() => handleNavigation('/my-profile')} className="w-full text-left p-2 hover:bg-gray-700 rounded">
                My Profile
              </button>
              <button onClick={() => handleNavigation('/my-incidents')} className="w-full text-left p-2 hover:bg-gray-700 rounded">
                My Incidents
              </button>
            </>
          )}

          {/* 🔴 Logout Button */}
          <button
            onClick={handleLogout}
            className="mt-4 w-full text-left p-2 bg-red-600 hover:bg-red-700 rounded"
          >
            Logout
          </button>
        </nav>
      </div>

      {/* Hamburger (can go in main layout or Navbar) */}
      <button
        onClick={toggleSidebar}
        className="sm:hidden fixed top-4 left-4 z-50 text-white bg-gray-800 p-2 rounded-md"
      >
        ☰
      </button>
    </>
  );
}

export default Sidebar;
