import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { getPatients, deletePatientData } from '../../utils/localStorage';
import { ToastContext } from '../../context/ToastContext';
import Navbar from '../Common/Navbar';
import Sidebar from './Sidebar';
import { AuthContext } from '../../context/AuthContext';

function PatientList() {
  const navigate = useNavigate();
  const { showToast } = useContext(ToastContext);
  const { user } = useContext(AuthContext);
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    setPatients(getPatients());
  }, []);

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this patient?')) {
      deletePatientData(id);
      setPatients(getPatients());
      showToast('Patient deleted successfully', 'success');
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar user={user} />
      <div className="flex-1 ml-0 sm:ml-64 p-15 sm:p-6 pt-4 sm:pt-5">
        <div className="hidden sm:block">
          <Navbar user={user} />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Patient List</h1>
        <button
          onClick={() => navigate('/patients/add')}
          className="bg-green-600 text-white px-4 py-2 rounded-lg mb-4 hover:bg-green-700 text-sm sm:text-base"
        >
          Add Patient
        </button>
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg overflow-x-auto sm:overflow-x-visible">
  <table className="w-full min-w-[640px]">
    <thead>
      <tr className="bg-blue-100 text-left">
        <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Photo</th>
        <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Name</th>
        <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">DOB</th>
        <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Contact</th>
        <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Health Info</th>
        <th className="p-2 sm:p-3 font-semibold text-sm sm:text-base">Actions</th>
      </tr>
    </thead>
    <tbody>
      {patients.map((patient) => (
        <tr key={patient.id} className="border-t hover:bg-gray-50 transition-colors">
          <td className="p-2 sm:p-3">
            <img
              src="https://via.placeholder.com/50"
              alt={patient.name}
              className="w-8 sm:w-10 h-8 sm:h-10 rounded-full"
            />
          </td>
          <td className="p-2 sm:p-3 text-xs sm:text-sm">{patient.name}</td>
          <td className="p-2 sm:p-3 text-xs sm:text-sm">{patient.dob}</td>
          <td className="p-2 sm:p-3 text-xs sm:text-sm">{patient.contact}</td>
          <td className="p-2 sm:p-3 text-xs sm:text-sm">{patient.healthInfo}</td>
          <td className="p-2 sm:p-3">
            <button
              onClick={() => navigate(`/patients/edit/${patient.id}`)}
              className="bg-blue-600 text-white px-2 sm:px-3 py-1 rounded-lg mr-2 hover:bg-blue-700 text-xs sm:text-sm"
            >
              Edit
            </button>
            <button
              onClick={() => handleDelete(patient.id)}
              className="bg-red-600 text-white px-2 sm:px-3 py-1 rounded-lg hover:bg-red-700 text-xs sm:text-sm"
            >
              Delete
            </button>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>

      </div>
    </div>
  );
}

export default PatientList;