import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { getIncidents, getPatients } from '../../utils/localStorage';
import Navbar from '../Common/Navbar';
import Sidebar from './Sidebar';

function Dashboard() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const incidents = getIncidents();
  const patients = getPatients();

  const upcomingAppointments = incidents
    .filter((i) => new Date(i.appointmentDate) >= new Date())
    .sort((a, b) => new Date(a.appointmentDate) - new Date(b.appointmentDate))
    .slice(0, 5);

  const pendingTreatments = incidents.filter((i) => i.status === 'Pending').length;
  const totalRevenue = incidents.reduce((sum, i) => sum + (i.cost || 0), 0);

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar user={user} />
      <div className="flex-1 ml-0 sm:ml-64 p-15 sm:p-6 pt-4 sm:pt-5">
        <div className="hidden sm:block">
          <Navbar user={user} />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Dashboard</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-6">
          <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg">
            <h2 className="text-base sm:text-lg font-semibold text-gray-700">Total Patients</h2>
            <p className="text-2xl sm:text-3xl text-blue-600">{patients.length}</p>
          </div>
          <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg">
            <h2 className="text-base sm:text-lg font-semibold text-gray-700">Pending Treatments</h2>
            <p className="text-2xl sm:text-3xl text-yellow-600">{pendingTreatments}</p>
          </div>
          <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg">
            <h2 className="text-base sm:text-lg font-semibold text-gray-700">Total Revenue</h2>
            <p className="text-2xl sm:text-3xl text-green-600">${totalRevenue.toFixed(2)}</p>
          </div>
        </div>
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg">
          <h2 className="text-base sm:text-lg font-semibold text-gray-700 mb-4">Upcoming Appointments</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingAppointments.map((incident) => (
              <div key={incident.id} className="bg-gray-50 p-4 rounded-lg shadow">
                <img
                  src="https://via.placeholder.com/150"
                  alt="Appointment"
                  className="w-full h-32 object-cover rounded-t-lg"
                />
                <p className="mt-2 text-gray-800 text-sm sm:text-base">{incident.title}</p>
                <p className="text-xs sm:text-sm text-gray-600">
                  {patients.find((p) => p.id === incident.patientId)?.name || 'Unknown'} -{' '}
                  {new Date(incident.appointmentDate).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;