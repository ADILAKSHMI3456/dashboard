import React, { useContext } from 'react';
import { getIncidents, getPatients } from '../../utils/localStorage';
import { AuthContext } from '../../context/AuthContext';
import Navbar from '../Common/Navbar';

function MyIncidents() {
  const { user } = useContext(AuthContext);
  const incidents = getIncidents().filter((i) => i.patientId === user.patientId);
  const patients = getPatients();

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar user={user} />
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <h2 className="text-3xl font-bold mb-6 text-blue-600">My Incidents</h2>
        <div className="bg-white p-6 rounded-lg shadow-lg overflow-x-auto">
          <table className="w-full min-w-max">
            <thead>
              <tr className="bg-blue-100 text-left">
                <th className="p-3 font-semibold">Title</th>
                <th className="p-3 font-semibold">Date</th>
                <th className="p-3 font-semibold">Status</th>
                <th className="p-3 font-semibold">Cost</th>
                <th className="p-3 font-semibold">Treatment</th>
                <th className="p-3 font-semibold">Next Date</th>
                <th className="p-3 font-semibold">Files</th>
              </tr>
            </thead>
            <tbody>
              {incidents.map((incident) => (
                <tr key={incident.id} className="border-t hover:bg-gray-50 transition-colors">
                  <td className="p-3">{incident.title}</td>
                  <td className="p-3">{new Date(incident.appointmentDate).toLocaleString()}</td>
                  <td className="p-3">{incident.status}</td>
                  <td className="p-3">${incident.cost || 0}</td>
                  <td className="p-3">{incident.treatment || '-'}</td>
                  <td className="p-3">{incident.nextDate || '-'}</td>
                  <td className="p-3">
                    {incident.files.map((file, index) => (
                      <a
                        key={index}
                        href={file.url}
                        download={file.name}
                        className="text-blue-500 hover:underline hover:text-blue-600 mr-2"
                      >
                        {file.name}
                      </a>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default MyIncidents;