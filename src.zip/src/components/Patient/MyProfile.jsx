import React, { useContext } from 'react';
import { getPatients } from '../../utils/localStorage';
import { AuthContext } from '../../context/AuthContext';
import Navbar from '../Common/Navbar';

function MyProfile() {
  const { user } = useContext(AuthContext);
  const patients = getPatients();
  const patient = patients.find((p) => p.id === user.patientId);

  if (!patient) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Navbar user={user} />
        <div className="max-w-md mx-auto p-4 sm:p-6 lg:p-8">
          <p className="text-red-500">No profile found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar user={user} />
      <div className="max-w-md mx-auto p-4 sm:p-6 lg:p-8">
        <h2 className="text-3xl font-bold mb-6 text-blue-600">My Profile</h2>
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <p className="mb-2"><strong className="text-gray-700">Name:</strong> {patient.name}</p>
          <p className="mb-2"><strong className="text-gray-700">Date of Birth:</strong> {patient.dob}</p>
          <p className="mb-2"><strong className="text-gray-700">Contact:</strong> {patient.contact}</p>
          <p><strong className="text-gray-700">Health Info:</strong> {patient.healthInfo}</p>
        </div>
      </div>
    </div>
  );
}

export default MyProfile;