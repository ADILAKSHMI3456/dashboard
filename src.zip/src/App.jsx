import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import PrivateRoute from './components/Auth/PrivateRoute';
import Login from './components/Auth/Login';
import Dashboard from './components/Admin/Dashboard';
import PatientList from './components/Admin/PatientList';
import PatientForm from './components/Admin/PatientForm';
import IncidentList from './components/Admin/IncidentList';
import IncidentForm from './components/Admin/IncidentForm';
import CalendarView from './components/Admin/CalendarView';
import MyProfile from './components/Patient/MyProfile';
import MyIncidents from './components/Patient/MyIncidents';
import Home from './components/Public/Home';
import AboutUs from './components/Public/AboutUs';
import ContactUs from './components/Public/ContactUs';
import Testimonials from './components/Public/Testimonials';
import Services from './components/Public/Services';
import Toast from './components/Common/Toast';
import ErrorBoundary from './components/Common/ErrorBoundary';
import PrivacyPolicyPage from './components/Public/privacy&policy';
import TermsAndConditionsPage from './components/Public/terms&conditions';

function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <Router>
          <ErrorBoundary>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/about-us" element={<AboutUs />} />
              <Route path="/contact-us" element={<ContactUs />} />
              <Route path="/testimonials" element={<Testimonials />} />
              <Route path="/services" element={<Services />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/terms" element={<TermsAndConditionsPage/>} />
              <Route
                path="/dashboard"
                element={
                  <PrivateRoute>
                    <Dashboard />
                  </PrivateRoute>
                }
              />
              <Route
                path="/patients"
                element={
                  <PrivateRoute role="Admin">
                    <PatientList />
                  </PrivateRoute>
                }
              />
              <Route
                path="/patients/add"
                element={
                  <PrivateRoute role="Admin">
                    <PatientForm />
                  </PrivateRoute>
                }
              />
              <Route
                path="/patients/edit/:id"
                element={
                  <PrivateRoute role="Admin">
                    <PatientForm />
                  </PrivateRoute>
                }
              />
              <Route
                path="/incidents"
                element={
                  <PrivateRoute role="Admin">
                    <IncidentList />
                  </PrivateRoute>
                }
              />
              <Route
                path="/incidents/add"
                element={
                  <PrivateRoute role="Admin">
                    <IncidentForm />
                  </PrivateRoute>
                }
              />
              <Route
                path="/incidents/edit/:id"
                element={
                  <PrivateRoute role="Admin">
                    <IncidentForm />
                  </PrivateRoute>
                }
              />
              <Route
                path="/calendar"
                element={
                  <PrivateRoute role="Admin">
                    <CalendarView />
                  </PrivateRoute>
                }
              />
              <Route
                path="/my-profile"
                element={
                  <PrivateRoute role="Patient">
                    <MyProfile />
                  </PrivateRoute>
                }
              />
              <Route
                path="/my-incidents"
                element={
                  <PrivateRoute role="Patient">
                    <MyIncidents />
                  </PrivateRoute>
                }
              />
            </Routes>
            <Toast />
          </ErrorBoundary>
        </Router>
      </ToastProvider>
    </AuthProvider>
  );
}

export default App;