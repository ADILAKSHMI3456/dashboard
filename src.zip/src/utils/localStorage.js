export const getUsers = () => {
  return JSON.parse(localStorage.getItem('users')) || [];
};

export const setUsers = (users) => {
  localStorage.setItem('users', JSON.stringify(users));
};

export const getPatients = () => {
  return JSON.parse(localStorage.getItem('patients')) || [
    {
      id: 'p1',
      name: 'John Doe',
      dob: '1990-05-10',
      contact: '1234567890',
      healthInfo: 'No allergies',
    },
  ];
};

export const setPatients = (patients) => {
  localStorage.setItem('patients', JSON.stringify(patients));
};

export const getIncidents = () => {
  return JSON.parse(localStorage.getItem('incidents')) || [
    {
      id: 'i1',
      patientId: 'p1',
      title: 'Toothache',
      description: 'Upper molar pain',
      comments: 'Sensitive to cold',
      appointmentDate: '2025-07-01T10:00:00',
      cost: 80,
      treatment: 'Filling',
      status: 'Completed',
      nextDate: '',
      files: [],
    },
  ];
};

export const setIncidents = (incidents) => {
  localStorage.setItem('incidents', JSON.stringify(incidents));
};

export const deletePatientData = (patientId) => {
  const patients = getPatients().filter((p) => p.id !== patientId);
  const incidents = getIncidents().filter((i) => i.patientId !== patientId);
  setPatients(patients);
  setIncidents(incidents);
};