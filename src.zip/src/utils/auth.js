import { getUsers } from './localStorage';

export const loginUser = (email, password) => {
  const users = getUsers();
  const user = users.find((u) => u.email === email && u.password === password);
  return user || null;
};

export const logoutUser = () => {
  localStorage.removeItem('user');
};